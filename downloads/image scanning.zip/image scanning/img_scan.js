const fs = require('fs')
const Jimp = require('jimp')

// Look for images in the folder
let directory = fs.readdirSync("./")
let extensions = [".png", ".jpg", ".jpeg", ".bmp"]
let file = directory.find(x => extensions.some(y => x.toLowerCase().endsWith(y)))
if (!file) return console.log("Could not find any image files! Drag a small PNG or JPEG into this folder.")

// Get the amount of pixels in the image
Jimp.read("./" + file).then(async img => {
  let imageSize = img.bitmap.width * img.bitmap.height;
  console.log(`${file} Has ${imageSize} pixels`);
});